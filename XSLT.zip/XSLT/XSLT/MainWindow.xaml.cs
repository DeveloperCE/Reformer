﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;

namespace XSLT
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            XMLEdit.doc.Load("Data1.xml");
            XmlElement root = XMLEdit.doc.DocumentElement;
            if (root != null)
            {
                int i = 1;
                foreach (XmlElement xnode in root)
                {
                    Employees.RowDefinitions.Add(new RowDefinition());
                    addTextBlock(xnode.Attributes.GetNamedItem("name").Value,i,0);
                    addTextBlock(xnode.Attributes.GetNamedItem("surname").Value, i, 1);
                    addTextBlock(xnode.Attributes.GetNamedItem("amount").Value, i, 2);
                    addTextBlock(xnode.Attributes.GetNamedItem("mount").Value, i, 3);
                    i++;
                }
            }
        }

        void addTextBlock(string text, int row, int column)
        {
            TextBlock textBlock = new TextBlock();
            textBlock.FontSize = 20;
            Grid.SetRow(textBlock, row);
            Grid.SetColumn(textBlock, column);
            textBlock.Text = text;
            Employees.Children.Add(textBlock);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            XMLEdit.reform();
        }
    }

    static class XMLEdit
    {
        public static XmlDocument doc = new XmlDocument();

        public static void reform()
        {
            XslCompiledTransform XslTrans = new XslCompiledTransform();
            XslTrans.Load("Code.xslt");
            XmlTextWriter Writer = new XmlTextWriter("result.xml", null);
            XslTrans.Transform(doc, null, Writer);
        }
    }
}
