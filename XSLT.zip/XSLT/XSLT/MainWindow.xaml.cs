﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;

using System.IO;

namespace XSLT
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            XMLEdit.load();
            gridLoad();
        }

        void gridLoad()
        {
            if (XMLEdit.Data1.DocumentElement != null)
            {
                int i = 1;
                foreach (XmlElement xnode in XMLEdit.Data1.DocumentElement)
                {
                    Employees.RowDefinitions.Add(new RowDefinition());
                    addTextBlock(xnode.Attributes.GetNamedItem("name").Value, i, 0);
                    addTextBlock(xnode.Attributes.GetNamedItem("surname").Value, i, 1);
                    addTextBlock(xnode.Attributes.GetNamedItem("amount").Value, i, 2);
                    addTextBlock(xnode.Attributes.GetNamedItem("mount").Value, i, 3);
                    i++;
                }
            }
        }

        void addTextBlock(string text, int row, int column)
        {
            TextBlock textBlock = new TextBlock();
            textBlock.FontSize = 20;
            Grid.SetRow(textBlock, row);
            Grid.SetColumn(textBlock, column);
            textBlock.Text = text;
            Employees.Children.Add(textBlock);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            XMLEdit.reform();
            this.Close();
        }
    }

    static class XMLEdit
    {
        public static XmlDocument Data1 = new XmlDocument();
        public static XmlDocument Employees = new XmlDocument();

        public static void load()
        {
            XMLEdit.Data1.Load("Data1.xml");
        }

        public static void reform()
        {

            /*            XslCompiledTransform XslTrans = new XslCompiledTransform();
                        XslTrans.Load("2.xsl");
                        XmlTextWriter Writer = new XmlTextWriter("3.xml", null);
                        XslTrans.Transform(doc, null, Writer);*/

            employeesAddSum();
            data1AddSum();
        }

        public static void employeesAddSum()
        {
            Employees.Load("Employees.xml");

            if (Employees.DocumentElement != null)
            {
                string name = String.Empty;
                decimal sum = 0;
                foreach (XmlElement Employee in Employees.DocumentElement)
                {
                    foreach (XmlElement salary in Employee)
                    {
                        sum += Convert.ToDecimal(salary.Attributes.GetNamedItem("amount").Value.Replace('.', ','));
                    }
                    var attrSum = Employees.CreateAttribute("sum");
                    attrSum.Value = sum.ToString();
                    Employee.SetAttributeNode(attrSum);
                    sum = 0;
                }
            }
            Employees.Save("Employees.xml");
        }

        public static void data1AddSum()
        {

            if (Data1.DocumentElement != null)
            {
                string name = String.Empty;
                decimal sum = 0;
                foreach (XmlElement item in Data1.DocumentElement)
                {
                    sum += Convert.ToDecimal(item.Attributes.GetNamedItem("amount").Value.Replace('.', ','));
                }
                var attrSum = Employees.CreateAttribute("sum");
                attrSum.Value = sum.ToString();
                Data1.DocumentElement.SetAttributeNode(attrSum);
                sum = 0;
            }
            Data1.Save("Data1.xml");
        }
    }
}
