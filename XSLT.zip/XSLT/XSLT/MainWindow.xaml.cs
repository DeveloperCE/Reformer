﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;

using System.IO;

namespace XSLT
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        int row = 0;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            XMLEdit.load();
            gridLoad();
        }

        void gridLoad()
        {
            if (XMLEdit.Data.DocumentElement != null)
            {
                row = 1;
                foreach (XmlElement xnode in XMLEdit.Data.DocumentElement)
                {
                    Employees.RowDefinitions.Add(new RowDefinition());
                    addTextBlock(xnode.Attributes.GetNamedItem("name").Value, row, 0);
                    addTextBlock(xnode.Attributes.GetNamedItem("surname").Value, row, 1);
                    addTextBlock(xnode.Attributes.GetNamedItem("amount").Value, row, 2);
                    addTextBlock(xnode.Attributes.GetNamedItem("mount").Value, row, 3);
                    row++;
                }
            }
        }

        void addTextBlock(string text, int row, int column)
        {
            TextBlock textBlock = new TextBlock();
            textBlock.FontSize = 20;
            Grid.SetRow(textBlock, row);
            Grid.SetColumn(textBlock, column);
            textBlock.Text = text;
            Employees.Children.Add(textBlock);
        }

/*        void addTextBox(string text, int row, int column, string name)
        {
            TextBox textBox = new TextBox();
            textBox.Name = name;
            textBox.FontSize = 20;
            Grid.SetRow(textBox, row);
            Grid.SetColumn(textBox, column);
            textBox.Text = text;
            Employees.Children.Add(textBox);
        }*/

        private void Reform_Click(object sender, RoutedEventArgs e)
        {
            XMLEdit.reform();
            this.Close();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            XMLEdit.addNewRow(Name.Text, Surname.Text, Amount.Text, Mount.Text);

            XMLEdit.reform();
            this.Close();
        }
    }

    static class XMLEdit
    {
        public static XmlDocument Data = new XmlDocument();
        public static XmlDocument Employees = new XmlDocument();

        public static void load()
        {
            XMLEdit.Data.Load("Data1.xml");
        }

        public static void addNewRow(string name, string surname, string amount, string mount)
        {
            var item = XMLEdit.Data.CreateElement("item");
            XmlAttribute nameAttr = XMLEdit.Data.CreateAttribute("name");
            nameAttr.Value = name;
            item.Attributes.Append(nameAttr);
            XmlAttribute surnameAttr = XMLEdit.Data.CreateAttribute("surname");
            surnameAttr.Value = surname;
            item.Attributes.Append(surnameAttr);
            XmlAttribute amountAttr = XMLEdit.Data.CreateAttribute("amount");
            amountAttr.Value = amount;
            item.Attributes.Append(amountAttr);
            XmlAttribute mountAttr = XMLEdit.Data.CreateAttribute("mount");
            mountAttr.Value = mount;
            item.Attributes.Append(mountAttr);


            XMLEdit.Data.SelectSingleNode("//Pay").AppendChild(item);
            XMLEdit.Data.Save("Data1.xml");
        }

        public static void reform()
        {
            XslCompiledTransform XslTrans = new XslCompiledTransform();
            XslTrans.Load("Code.xsl");
            using (XmlTextWriter Writer = new XmlTextWriter("Employees.xml", null)) //Нужно освободить Employees.xml
            {
                XslTrans.Transform(Data, null, Writer);
            }

            employeesAddSum();
            DataAddSum();
        }

        public static void employeesAddSum()
        {
            Employees.Load("Employees.xml");

            if (Employees.DocumentElement != null)
            {
                string name = String.Empty;
                decimal sum = 0;
                foreach (XmlElement Employee in Employees.DocumentElement)
                {
                    foreach (XmlElement salary in Employee)
                    {
                        sum += Convert.ToDecimal(salary.Attributes.GetNamedItem("amount").Value.Replace('.', ','));
                    }
                    var attrSum = Employees.CreateAttribute("sum");
                    attrSum.Value = sum.ToString();
                    Employee.SetAttributeNode(attrSum);
                    sum = 0;
                }
            }
            Employees.Save("Employees.xml");
        }

        public static void DataAddSum()
        {

            if (Data.DocumentElement != null)
            {
                string name = String.Empty;
                decimal sum = 0;
                foreach (XmlElement item in Data.DocumentElement)
                {
                    sum += Convert.ToDecimal(item.Attributes.GetNamedItem("amount").Value.Replace('.', ','));
                }
                var attrSum = Employees.CreateAttribute("sum");
                attrSum.Value = sum.ToString();
                Data.DocumentElement.SetAttributeNode(attrSum);
                sum = 0;
            }
            Data.Save("Data.xml");
        }
    }
}
